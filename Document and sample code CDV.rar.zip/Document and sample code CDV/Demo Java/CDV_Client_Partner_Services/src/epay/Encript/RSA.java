package epay.Encript;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.EncodedKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;


public class RSA {
	public static String private_key;
	public static String public_key;
	public static void genKey(){
		try {
			KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
			keyGen.initialize(1024);
			KeyPair keypair = keyGen.genKeyPair();;
			PrivateKey privateKey = keypair.getPrivate();;
			PublicKey publicKey = keypair.getPublic();
			//
			BASE64Encoder encoder = new BASE64Encoder();
			private_key = encoder.encode(privateKey.getEncoded());
			public_key = encoder.encode(publicKey.getEncoded());
			
			System.out.println("This is privatekey: \n" + private_key);
			System.out.println("This is publickey: \n" + public_key);
			//Write to file:
			writeKeyBytesToFile(private_key.getBytes(), "KEY/private_key.pem");
			writeKeyBytesToFile(public_key.getBytes(), "KEY/public_key.pem");
			//
			RSAPublicKey rsaPublicKey = (RSAPublicKey) KeyFactory.getInstance(
					"RSA").generatePublic(
					new X509EncodedKeySpec(publicKey.getEncoded()));
			String xml = getRSAPublicKeyAsXMLString(rsaPublicKey);
			writeKeyBytesToFile(xml.getBytes(), "keyRSA/public_key.xml");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private static void writeKeyBytesToFile(byte[] key, String file)
			throws IOException {
		OutputStream out = new FileOutputStream(file);
		out.write(key);
		out.close();
	}
	//Read key
	public static void initializeKeys() {
		private_key = Readfile("keyRSA/private_key.pem");
		System.out.println("Read Private key:");
		System.out.println(private_key);
		public_key = Readfile("keyRSA/public_key.pem");
		System.out.println("Read Public key:");
		System.out.println(public_key);
	}
	private static String Readfile(String path) {
		String xau = "";
		try {
			FileInputStream fstream = new FileInputStream(path);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			while ((strLine = br.readLine()) != null) {
				xau += strLine + " ";
			}
			xau = xau.trim();
			xau = xau.replace(" ", "\n");
			br.close();
			in.close();
			fstream.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return xau;
	}
	private static String getRSAPublicKeyAsXMLString(RSAPublicKey key)
			throws UnsupportedEncodingException, ParserConfigurationException,
			TransformerException {
		Document xml = getRSAPublicKeyAsXML(key);
		Transformer transformer = TransformerFactory.newInstance()
				.newTransformer();
		StringWriter sw = new StringWriter();
		transformer.transform(new DOMSource(xml), new StreamResult(sw));
		return sw.getBuffer().toString();
	}
	private static Document getRSAPublicKeyAsXML(RSAPublicKey key)
			throws ParserConfigurationException, UnsupportedEncodingException {
		Document result = DocumentBuilderFactory.newInstance()
				.newDocumentBuilder().newDocument();
		Element rsaKeyValue = result.createElement("RSAKeyValue");
		result.appendChild(rsaKeyValue);
		Element modulus = result.createElement("Modulus");
		rsaKeyValue.appendChild(modulus);

		byte[] modulusBytes = key.getModulus().toByteArray();
		modulusBytes = stripLeadingZeros(modulusBytes);
		modulus.appendChild(result.createTextNode(new String(
				new sun.misc.BASE64Encoder().encode(modulusBytes))));

		Element exponent = result.createElement("Exponent");
		rsaKeyValue.appendChild(exponent);

		byte[] exponentBytes = key.getPublicExponent().toByteArray();
		exponent.appendChild(result.createTextNode(new String(
				new sun.misc.BASE64Encoder().encode(exponentBytes))));

		return result;
	}
	private static byte[] stripLeadingZeros(byte[] a) {
		int lastZero = -1;
		for (int i = 0; i < a.length; i++) {
			if (a[i] == 0) {
				lastZero = i;
			} else {
				break;
			}
		}
		lastZero++;
		byte[] result = new byte[a.length - lastZero];
		System.arraycopy(a, lastZero, result, 0, result.length);
		return result;
	}
	
	//
	public static String sign(String data, String key_private){
		try {
			BASE64Decoder decode = new BASE64Decoder();
			byte[] privateKeyBytes = decode.decodeBuffer(key_private);
//			byte[] privateKeyBytes = key_private.getBytes();
			PrivateKey privateKey = KeyFactory.getInstance("RSA")
					.generatePrivate(new PKCS8EncodedKeySpec(privateKeyBytes));
			Signature rsa = Signature.getInstance("SHA1withRSA");
			rsa.initSign(privateKey);
			rsa.update(data.getBytes());
			//
			BASE64Encoder encoder = new BASE64Encoder();
			return encoder.encode(rsa.sign());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static boolean verify(String data, String sign, String key_public){
		try {
			BASE64Decoder decode = new BASE64Decoder();
			byte[] publicKeyBytes = decode.decodeBuffer(key_public);
//			byte[] publicKeyBytes = key_public.getBytes();
			PublicKey publicKey = KeyFactory.getInstance("RSA").generatePublic(
					new X509EncodedKeySpec(publicKeyBytes));
			Signature rsa = Signature.getInstance("SHA1withRSA");
			rsa.initVerify(publicKey);
			rsa.update(data.getBytes());
			byte[] signByte = decode.decodeBuffer(sign);
			return (rsa.verify(signByte));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public static void main(String[] args) {
		genKey();
//		initializeKeys();
//		String data = "epay_testepay_test_113640_542613232000{\"listAccount\":[\"0901111111|11000|2|VMS\",\"0911111111|21000|4|VNP\"]}11:36:40 19/08/201311:36:40 20/08/2013";
//		String sign = sign(data, private_key);
//		System.out.println("Sign: " + sign);
//		System.out.println("Verify: " + verify(data, sign, public_key));
	}
}
