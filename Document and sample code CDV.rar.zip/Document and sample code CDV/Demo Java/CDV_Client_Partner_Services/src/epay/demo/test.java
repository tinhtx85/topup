package epay.demo;

import java.net.URL;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import epay.Encript.RSA;
import epay.Encript.TripleDES;
import epay.services.CheckOrdesrCDVResult;
import epay.services.CheckTransResult;
import epay.services.DownloadSoftpinResult;
import epay.services.InterfacesSoapBindingStub;
import epay.services.PaymentCdvResult;
import epay.services.QueryBalanceResult;
import epay.services.TopupResult;

public class test {
//	static String webservice_url = "http://172.16.10.69:8080/CDV_Partner_Services/services/Interfaces?wsdl";
	static String webservice_url = "http://itopup-test.megapay.net.vn:8086/CDV_Partner_Services/services/Interfaces?wsdl";
	static String key_private_RSA = "";
	static String key_3DES = "123456abc";
	private static InterfacesSoapBindingStub service = null;

	public static InterfacesSoapBindingStub getService() throws Exception {
		if (service == null) {
			URL oUrl = new URL(webservice_url);
			service = new InterfacesSoapBindingStub(oUrl, null);
			service.setTimeout(300000);
		}
		return service;
	}
	public static String createRequestID(String partnerName){
		String requestID = "";
		try {
			Date today = new Date();
			Timestamp timeNow = new Timestamp(today.getTime());
			SimpleDateFormat dateFormat = new SimpleDateFormat("HHmmss");
			String strDate = dateFormat.format(timeNow);
			Random random = new Random();
			int subResult = 0;
			do {
				subResult = random.nextInt(999999);
			} while (subResult < 100000);
			return partnerName + "_" + strDate + "_" +subResult;
		} catch (Exception e) {
			requestID = "";
			e.printStackTrace();
		}
		return requestID;
	}
	public static void queryBalance(String partnerName){
		try {
			if(key_private_RSA == null || key_private_RSA.equals("")) {
				RSA.initializeKeys();
				key_private_RSA = RSA.private_key;
			}
			String dataSign =  partnerName;
			String sign = RSA.sign(dataSign, key_private_RSA);
			QueryBalanceResult result = getService().queryBalance(partnerName, sign);
			System.out.println(result.getErrorCode());
			System.out.println(result.getMessage());
			System.out.println(result.getBalance_money());
			System.out.println(result.getBalance_bonus());
			System.out.println(result.getBalance_debit());
			System.out.println(result.getBalance_avaiable());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void paymentCDV(String requestId, String partnerName,
			String provider, int type, String account, long amount, int timeOut){
		try {
			if(key_private_RSA == null || key_private_RSA.equals("")) {
				RSA.initializeKeys();
				key_private_RSA = RSA.private_key;
			}
			
			
			requestId	=	"partnerTest_PHP_1421832784304";
			partnerName	=	"partnerTest_PHP";
			provider	=	"VNP";
			type		=	3;
			account		=	"0915599100";
			amount		=	10;
			timeOut		=	150;
			
			String dataSign = requestId + partnerName + provider + type + account + amount + timeOut;
			String sign = RSA.sign(dataSign, key_private_RSA);
			
			System.out.println("Sign:" + sign);
			
			
			
			PaymentCdvResult result = getService().paymentCDV(requestId, partnerName, provider, type, account, amount, timeOut, sign);
			System.out.println(result.getErrorCode());
			System.out.println(result.getMessage());
			System.out.println(result.getAmountTopupSuccess());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void topup(String requestId, String partnerName,
			String provider, String target, int amount){
		try {
			if(key_private_RSA == null || key_private_RSA.equals("")) {
				RSA.initializeKeys();
				key_private_RSA = RSA.private_key;
			}
			String dataSign = requestId + partnerName + provider + target + amount;
			String sign = RSA.sign(dataSign, key_private_RSA);
			TopupResult result = getService().topup(requestId, partnerName, provider, target, amount, sign);
			System.out.println(result.getErrorCode());
			System.out.println(result.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void checkOrdersCDV(String requestId, String partnerName){
		try {
			if(key_private_RSA == null || key_private_RSA.equals("")) {
				RSA.initializeKeys();
				key_private_RSA = RSA.private_key;
			}
			String dataSign = requestId + partnerName;
			String sign = RSA.sign(dataSign, key_private_RSA);
			CheckOrdesrCDVResult result = getService().checkOrdersCDV(requestId, partnerName, sign);
			System.out.println(result.getErrorCode());
			System.out.println(result.getMessage());
			System.out.println(result.getAmountTopupSuccess());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void checkTrans(String requestId, String partnerName, int type){
		try {
			System.out.println("Checking: partnerTest_141849_612460");
			if(key_private_RSA == null || key_private_RSA.equals("")) {
				RSA.initializeKeys();
				key_private_RSA = RSA.private_key;
			}
			String dataSign = requestId + partnerName + type;
			String sign = RSA.sign(dataSign, key_private_RSA);
			CheckTransResult result = getService().checkTrans(requestId, partnerName, type, sign);
			System.out.println(result.getErrorCode());
			System.out.println(result.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static int checkStore(String partnerName, String provider, int amount){
		int result = 0;
		try {
			if(key_private_RSA == null || key_private_RSA.equals("")) {
				RSA.initializeKeys();
				key_private_RSA = RSA.private_key;
			}
			String dataSign = partnerName + provider + amount;
			String sign = RSA.sign(dataSign, key_private_RSA);
			result = getService().checkStore(partnerName, provider, amount, sign);
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public static void downloadSoftpin(String requestId,
			String partnerName, String provider, int amount, int quantity){
		try {
			if(key_private_RSA == null || key_private_RSA.equals("")) {
				RSA.initializeKeys();
				key_private_RSA = RSA.private_key;
			}
			String dataSign = requestId + partnerName + provider + amount + quantity;
			String sign = RSA.sign(dataSign, key_private_RSA);
			DownloadSoftpinResult result = getService().downloadSoftpin(requestId, partnerName, provider, amount, quantity, sign);
			System.out.println("Code: " + result.getErrorCode());
			System.out.println("Msg: " + result.getMessage());
			System.out.println(result.getListCards());
			if(!result.getListCards().equals(""))
				System.out.println(TripleDES.Decrypt(result.getListCards(), key_3DES));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void reDownloadSoftpin(String requestId,String partnerName){
		try {
			if(key_private_RSA == null || key_private_RSA.equals("")) {
				RSA.initializeKeys();
				key_private_RSA = RSA.private_key;
			}
			String dataSign = requestId + partnerName;
			String sign = RSA.sign(dataSign, key_private_RSA);
			DownloadSoftpinResult result = getService().reDownloadSoftpin(requestId, partnerName, sign);
			System.out.println(result.getErrorCode());
			System.out.println(result.getMessage());
			System.out.println(result.getListCards());
			if(!result.getListCards().equals(""))
				System.out.println(TripleDES.Decrypt(result.getListCards(), key_3DES));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		String partnerName = "partnerTest";
		String requestId = createRequestID(partnerName);
		System.out.println("RequestId: " + requestId);
//		paymentCDV(requestId, partnerName, "VTT", 2, "0972334455", 400000, 300);
//		queryBalance(partnerName);
//		topup(requestId, partnerName, "VMS", "0904223344", 50000);  
//		checkOrdersCDV("partnerTest_133121_729574", partnerName);
		checkTrans("partnerTest_141849_612460", partnerName, 1);
//		checkStore("partnerTest", "VMS", 10000);
//		downloadSoftpin(requestId, partnerName, "VTT", 10000, 1);
		//reDownloadSoftpin("partnerTest_115126_212722", partnerName);
	}
	
}
