/**
 * CheckOrdesrCDVResult.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package epay.services;

public class CheckOrdesrCDVResult  implements java.io.Serializable {
    private long amountTopupSuccess;

    private int errorCode;

    private java.lang.String message;

    public CheckOrdesrCDVResult() {
    }

    public CheckOrdesrCDVResult(
           long amountTopupSuccess,
           int errorCode,
           java.lang.String message) {
           this.amountTopupSuccess = amountTopupSuccess;
           this.errorCode = errorCode;
           this.message = message;
    }


    /**
     * Gets the amountTopupSuccess value for this CheckOrdesrCDVResult.
     * 
     * @return amountTopupSuccess
     */
    public long getAmountTopupSuccess() {
        return amountTopupSuccess;
    }


    /**
     * Sets the amountTopupSuccess value for this CheckOrdesrCDVResult.
     * 
     * @param amountTopupSuccess
     */
    public void setAmountTopupSuccess(long amountTopupSuccess) {
        this.amountTopupSuccess = amountTopupSuccess;
    }


    /**
     * Gets the errorCode value for this CheckOrdesrCDVResult.
     * 
     * @return errorCode
     */
    public int getErrorCode() {
        return errorCode;
    }


    /**
     * Sets the errorCode value for this CheckOrdesrCDVResult.
     * 
     * @param errorCode
     */
    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }


    /**
     * Gets the message value for this CheckOrdesrCDVResult.
     * 
     * @return message
     */
    public java.lang.String getMessage() {
        return message;
    }


    /**
     * Sets the message value for this CheckOrdesrCDVResult.
     * 
     * @param message
     */
    public void setMessage(java.lang.String message) {
        this.message = message;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CheckOrdesrCDVResult)) return false;
        CheckOrdesrCDVResult other = (CheckOrdesrCDVResult) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.amountTopupSuccess == other.getAmountTopupSuccess() &&
            this.errorCode == other.getErrorCode() &&
            ((this.message==null && other.getMessage()==null) || 
             (this.message!=null &&
              this.message.equals(other.getMessage())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += new Long(getAmountTopupSuccess()).hashCode();
        _hashCode += getErrorCode();
        if (getMessage() != null) {
            _hashCode += getMessage().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CheckOrdesrCDVResult.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.epay", "CheckOrdesrCDVResult"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("amountTopupSuccess");
        elemField.setXmlName(new javax.xml.namespace.QName("", "amountTopupSuccess"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("errorCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "errorCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("message");
        elemField.setXmlName(new javax.xml.namespace.QName("", "message"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
