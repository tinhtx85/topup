<?php
$config = array(
    //link webservice
    'ws_url' => 'http://itopup-test.megapay.net.vn:8086/CDV_Partner_Services/services/Interfaces?wsdl',

    //partner username
    'partnerName' => 'partnerTest_PHP',

    //partner password
    'partnerPassword' => '123456abc',

    //key sofpin
    'key_sofpin' => '123456abc',

    //thời gian tối đa thực hiện giao dịch (tính bằng giây)
    'time_out' => 150

);
?>