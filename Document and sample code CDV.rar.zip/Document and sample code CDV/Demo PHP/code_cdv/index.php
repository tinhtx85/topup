<meta charset="utf-8" />
<a href="payment.php">Thanh Toán</a><br/><br/>
<a href="topup.php">Topup</a><br/><br/>
<a href="downloadSoftpin.php">Download Sofpin</a><br/><br/>
<a href="queryBalance.php">Kiểm tra số dư (Query Balance)</a><br/><br/>
<a href="checkOrdersCDV.php">check Orders CDV</a><br/><br/>
<a href="checkTrans.php">check Trans</a><br/><br/>
<a href="redownloadSoftpin.php">redownload Softpin</a><br/><br/>


